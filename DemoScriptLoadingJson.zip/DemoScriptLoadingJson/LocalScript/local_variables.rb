require 'yaml'
require 'json'
require 'erb'

# ======== Define paths ========
yml_path            = './LocalScript/LocalVariable.yml'
enum_template_path  = './LocalScript/LocalVariable.swift.erb'
ext_template_path   = './LocalScript/LocalVariable+generated.swift.erb'

# Output file paths
enum_output_path    = './DemoScriptLoadingJson/LocalVariable/LocalVariable.swift'
ext_output_path     = './DemoScriptLoadingJson/LocalVariable/LocalVariable+generated.swift'

# ======== Read and check YAML ========
data = YAML.load_file(yml_path)

pp data

variables = data.map do |key, value|
  unless value && value["name"] && value["owner"] && value["path"]
    raise "❌ Miss: key '#{key}' Miss 'name', 'owner' or 'path'"
  end

  json_path = value["path"]
  unless File.exist?(json_path)
    raise "❌ Error: JSON not found '#{json_path}' for key '#{key}'"
  end

  json_object = JSON.parse(File.read(json_path))
  escaped_json = JSON.generate(json_object).dump[1..-2]

  {
    key: key,
    comment: "#{value["name"]} - #{value["owner"]}",
    escaped_json: escaped_json
  }
end

# ======== Render và write file từ ERB ========
enum_template = ERB.new(File.read(enum_template_path), trim_mode: '-')
ext_template  = ERB.new(File.read(ext_template_path), trim_mode: '-')

File.write(enum_output_path, enum_template.result(binding))
File.write(ext_output_path, ext_template.result(binding))

puts "✅ Generate successfully:"
puts "- #{enum_output_path}"
puts "- #{ext_output_path}"
