#!/bin/bash
set -e
set -x

# Lấy đường dẫn thư mục gốc project từ biến môi trường Xcode
PROJECT_DIR="${SRCROOT}"

# Di chuyển vào thư mục chứa script
cd "$PROJECT_DIR"

# Chạy Ruby script
ruby "./LocalScript/local_variables.rb"