//
//  ViewController.swift
//  DemoScriptLoadingJson
//
//  Created by Kha Huynh on 5/30/25.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var label: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func loadJson(_ sender: Any) {
        label.text = LocalVariable.exploreStructure.rawValue
    }
    
}

