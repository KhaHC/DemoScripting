public enum LocalVariable: String, CaseIterable {

    /// Default value of explore page when LD was failed - Fansipan
    case exploreStructure

}
