extension LocalVariable {
    public var rawValue: String {
        switch self {

        case .exploreStructure:
            return "{\"menu\":[{\"menuId\":\"menu_id\",\"title\":\"Menu 1\",\"items\":[{\"config\":{\"type\":\"test type\",\"url\":\"http://google.com/test?param=1\"}}]}]}" 

        }
    }
}
